Hypnotic Theme - A GTK3 inspired by the Mac OS X theme.
=======================================

Installation
------------

Just copy the files to .themes/Hypnotic folder.


Demonstration
-------------

![Demonstration of Layout](demo01.jpg)
![Demonstration of Layout](demo02.jpg)
